import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface User {
  id: number;
  name: string;
}

const UserList: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]); // State to store the list of users
  const [error, setError] = useState<string>(''); // State to store the error message

  useEffect(() => {
    fetchUsers(); // Fetch users when the component mounts
  }, []);

  /*In the real world you would not assign the user variable to response.data
    For example a more correct implementation in updateUser would be
    const updateUser = async (userId: number, newName: string) => {
  try {
    const response = await axios.put<User>(`/api/users/${userId}`, { name: newName });
    const updatedUser = { ...response.data, name: newName }; // Update the name with the new name
    setUsers(prevUsers =>
      prevUsers.map(user => (user.id === userId ? updatedUser : user))
    );
    console.log('Updated successfully userId: ', userId);
  } catch (error) {
    console.error(`Error updating user with userId: ${userId}`, error);
  }
};

I think we can live with the existent code due to that test is in focus and not how we code react components
  */

const fetchUsers = async () => {
  try {
    const response = await axios.get<User[]>('/api/users'); // Fetch users from the API
    console.log('Function fetchUsers in UserList component got Response data:', JSON.stringify(response.data, null, 2), response.status);
    if (response && response.data) {
      setUsers(response.data); // Update the state with the fetched users
    } else {
      console.error('Invalid response:', response?.data, response?.status);
      setError('Failed to fetch users.');
    }
  } catch (error) {
    console.error('Error fetching users:', error);
    setError('Failed to fetch users.');
  }
};


  const addUser = async (name: string) => {
    try {
      console.log('Post request will be sent from addUser function in UserList component with name: ', name);
      const response = await axios.post<User>('/api/users', { name }); // Send a POST request to add a new user
      const newUser = response.data;
      if (newUser) {
        setUsers(prevUsers => [...prevUsers, newUser]); // Add the new user to the state
        console.log('UserList component Added user: ', response.data.name, response.data.id);
      } else {
        console.error('Error adding user: Invalid response');
      }
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };
  

  const updateUser = async (userId: number, newName: string) => {
    try {
      console.log(`POST request will be sent from updateUser function in UserList component for userId: ${userId}`);
      const response = await axios.post<User>(`/api/users/${userId}`, { name: newName });
      const updatedUser = response.data;
      console.log('API response in UserList component function updateUser was:', JSON.stringify(response.data, null, 2));
      if (response.data.name && response.data.name.length > 0) {
        setUsers(prevUsers =>
          prevUsers.map(user => (user.id === userId ? updatedUser : user))
        );
      } else {
        console.log('Response data in updateUser in UserList component was incorrect');
      }
    } catch (error) {
      console.error(`Error updating user with userId: ${userId}`, error);
    }
  };
  

  const deleteUser = async (userId: number) => {
    try {
      console.log('Delete request will be sent from deleteUser function in UserList component');
      await axios.delete(`/api/users/${userId}`); // Send a DELETE request to remove a user
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId)); // Update the state by removing the deleted user
      console.log('UserList Component Deleted userId: ', userId);
    } catch (error) {
      console.error(`Error deleting user with userId: ${userId}. Error was: ${error.message}`);
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const nameInput = e.currentTarget.querySelector(
      'input[name="name"]'
    ) as HTMLInputElement;
    if (nameInput) {
      const name = nameInput.value;
      addUser(name); // Add a new user when the form is submitted
      e.currentTarget.reset();
    }
  };

  // Rest of the component code...

  return (
    <div data-testid="user-list">
      {error && (
        <p className="error-message" data-testid="error-message">
          {error}
        </p>
      )}
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name}
            <button
              onClick={() => updateUser(user.id, 'Updated Name')}
              data-testid={`update-button-${user.id}`}
            >
              Update
            </button>
            <button 
              onClick={() => deleteUser(user.id)}
              data-testid={`delete-button-${user.id}`} 
            >
            Delete
            </button>
          </li>
        ))}
      </ul>
      <form onSubmit={handleSubmit} data-testid="user-list-form">
        <input type="text" name="name" placeholder="Enter name" />
        <button type="submit">Add User</button>
      </form>
    </div>
  );
};

export default UserList;
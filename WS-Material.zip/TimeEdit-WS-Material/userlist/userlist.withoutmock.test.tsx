import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import userEvent from '@testing-library/user-event';
import UserList from './userlist';

interface User {
  id: number;
  name: string;
}

test('Renders the list of users fetched from the API', async () => {
  render(<UserList />);

  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });
});

test('Add a new user through the API', async () => {
  render(<UserList />);

  const inputElement = screen.getByPlaceholderText('Enter name');
  const addButtonElement = screen.getByText('Add User');

  const newName = 'Jane';
  userEvent.type(inputElement, newName);
  userEvent.click(addButtonElement);

  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });
});

test('Delete a user through the API', async () => {
  render(<UserList />);

  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });

  const deleteButtons = screen.queryAllByText('Delete');
  const deleteButton = deleteButtons.find(button =>
    button.closest('li')?.textContent?.includes('John')
  );
  fireEvent.click(deleteButton);

  await waitFor(() => {
    expect(screen.queryByText('John')).toBeNull();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });
});

test('Update a user through the API', async () => {
  render(<UserList />);

  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });

  const updateButton = screen.getAllByText('Update')[0];
  userEvent.click(updateButton);

  const inputElement = screen.getByPlaceholderText('Enter name');
  userEvent.clear(inputElement);
  userEvent.type(inputElement, 'Tekla');
  fireEvent.keyDown(inputElement, { key: 'Enter', code: 'Enter' });

  await waitFor(() => {
    expect(screen.getByText('Tekla')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });
});

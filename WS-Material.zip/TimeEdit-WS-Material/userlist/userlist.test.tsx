const fs = require('fs');
const path = require('path');
const chalk = require('chalk'); //Just for fun
import moment from 'moment'; // Use default import

import React, { useState } from 'react';
//This imports the React library, which is used for building user interfaces in React applications.
import { render, screen, waitFor, within } from '@testing-library/react';

/*
These imports are from the '@testing-library/react' library, which provides utilities 
for testing React components.
render is used to render React components for testing.
screen provides functions for querying and interacting with the 
rendered components.
waitFor is used to wait for asynchronous events to complete before 
making assertions in tests.
*/
import '@testing-library/jest-dom/extend-expect';
/*
This import extends the expect function provided by 
Jest (the testing framework) to include additional matchers 
specifically designed for testing React components. It enhances the readability and 
functionality of the test assertions.
*/
import userEvent from '@testing-library/user-event';
/*
This import is from the '@testing-library/user-event' library, which provides 
simulated user events for testing React components. It allows you to 
programmatically simulate user interactions such as 
typing, clicking, selecting, etc., on the rendered components.
*/
import { fireEvent } from '@testing-library/dom'; 
/*
This import is from the '@testing-library/dom' library, which provides utilities for 
firing events on DOM elements. It allows you to 
simulate browser events, such as clicks or input changes, on the rendered components.
*/
import UserList from './userlist';
/*
This imports the 'UserList' component from the './userlist' file. It assumes that 
there is a file named 'userlist.js' or 'userlist.jsx' in the same directory 
as the current file.
*/
import axios from 'axios';
/*
This imports the axios library, which is a popular JavaScript library used for 
making HTTP requests. It provides a convenient way to 
communicate with APIs and retrieve data from remote servers.
*/
import { act } from '@testing-library/react';
/*
This import is from the '@testing-library/react' library and provides the act function. 
act is used to wrap code that triggers updates in React components during tests. It ensures that all state updates and side effects are 
correctly handled and propagated before making assertions.

*/
import { prettyDOM } from '@testing-library/react';

//Interface
interface User {
  id: number;
  name: string;
}

jest.mock('axios'); // Mock the axios module

//Console buffer
const consoleBuffer = [];
// Configuration to override console.log and create log file. Just for debug purpose
const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, '0');
const day = String(currentDate.getDate()).padStart(2, '0');
const hour = String(currentDate.getHours()).padStart(2, '0');
const minute = String(currentDate.getMinutes()).padStart(2, '0');
const second = String(currentDate.getSeconds()).padStart(2, '0');
const milliseconds = String(currentDate.getMilliseconds()).padStart(3, '0');

const logFileName = `userlist.test.tsx-${year}-${month}-${day}-${hour}.${minute}.${second}.log`;
const logDirectory = path.join(__dirname, 'log');
const logFilePath = path.join(logDirectory, logFileName);

if (!fs.existsSync(logDirectory)) {
  fs.mkdirSync(logDirectory);
}

const logStream = fs.createWriteStream(logFilePath, { flags: 'a' });

const bufferSize = 2000; // Set the desired buffer size

console.log = (...args) => {
  const message = args.join(' ');
  const timestamp = moment().format('YYYY-MM-DD HH:mm:ss.SSS'); // Include milliseconds
  const logEntry = `${timestamp} - ${message}`;

  consoleBuffer.push(logEntry);
  process.stdout.write(chalk.green(`${logEntry}\n`));

  // Check if buffer size is reached and flush the buffer
  if (consoleBuffer.length >= bufferSize) {
    flushConsoleBuffer();
  }
};

const flushConsoleBuffer = () => {
  logStream.write(consoleBuffer.join('\n') + '\n');
  consoleBuffer.length = 0; // Clear the buffer
};


console.log(chalk.green('Log stream is opened\n'));

console.log(chalk.green('Multiple Users will be created\n'));

const multiplelUserList: User[] = [
  { id: 1, name: 'John' },
  { id: 2, name: 'Jane' },
  { id: 3, name: 'Michael' },
  { id: 4, name: 'Emily' },
  { id: 5, name: 'William' },
  { id: 6, name: 'Olivia' },
  { id: 7, name: 'James' },
  { id: 8, name: 'Sophia' },
  { id: 9, name: 'Benjamina' },
  { id: 10, name: 'Isabella' },
  { id: 11, name: 'Liam' },
  { id: 12, name: 'Ava' },
  { id: 13, name: 'Lucas' },
  { id: 14, name: 'Mia' },
  { id: 15, name: 'Henrie' },
  { id: 16, name: 'Charlotte' },
  { id: 17, name: 'Ethan' },
  { id: 18, name: 'Amelia' },
  { id: 19, name: 'Alexander' },
  { id: 20, name: 'Harper' },
  { id: 21, name: 'Danny' },
  { id: 22, name: 'Evelyn' },
  { id: 23, name: 'Matthew' },
  { id: 24, name: 'Abigail' },
  { id: 25, name: 'Joseph' },
  { id: 26, name: 'Emilie' },
  { id: 27, name: 'Samuel' },
  { id: 28, name: 'Elizabeth' },
  { id: 29, name: 'David' },
  { id: 30, name: 'Sofia' },
  { id: 31, name: 'Benjamino' },
  { id: 32, name: 'Scarlett' },
  { id: 33, name: 'Jackson' },
  { id: 34, name: 'Grace' },
  { id: 35, name: 'Henry' },
  { id: 36, name: 'Victoria' },
  { id: 37, name: 'Sebastian' },
  { id: 38, name: 'Chloe' },
  { id: 39, name: 'Jack' },
  { id: 40, name: 'Penelope' },
  { id: 41, name: 'Andrew' },
  { id: 42, name: 'Layla' },
  { id: 43, name: 'Owen' },
  { id: 44, name: 'Zoe' },
  { id: 45, name: 'Wyatt' },
  { id: 46, name: 'Nora' },
  { id: 47, name: 'Daniel' },
  { id: 48, name: 'Lily' },
  { id: 49, name: 'Carter' },
  { id: 50, name: 'Madison' },
  { id: 51, name: 'Tomas' },
  { id: 52, name: 'Reg' },
];

console.log(chalk.green(' Small User list will be created\n'));

const smallUserList: User[] = [
  { id: 1, name: 'John' },
  { id: 2, name: 'Jane' },
  { id: 3, name: 'Michael' },
  { id: 4, name: 'Lily' },
  { id: 5, name: 'Carter' },
  { id: 6, name: 'Madison' },
  { id: 7, name: 'Tomas' },
  { id: 8, name: 'Reg' },
  { id: 9, name: 'Andrew' },
  { id: 10, name: 'Layla' },
  { id: 11, name: 'Liam' },
  { id: 12, name: 'Ava' },
  { id: 13, name: 'Lucas' },
  { id: 14, name: 'Mia' },
  { id: 15, name: 'Henrie' },
  { id: 16, name: 'Charlotte' },
  { id: 17, name: 'Ethan' },
  { id: 18, name: 'Amelia' },
  { id: 19, name: 'Alexander' },
  { id: 20, name: 'Harper' },
  { id: 21, name: 'Danny' },
  { id: 22, name: 'Evelyn' },
  { id: 23, name: 'Matthew' },
  { id: 24, name: 'Abigail' },
  { id: 25, name: 'Rasbert' },
];

const miniUserList: User[] = [
  { id: 1, name: 'Putte' },
  { id: 2, name: 'Humle' },
  { id: 3, name: 'Dumle' },
  { id: 4, name: 'Lily' },
  { id: 5, name: 'Ellinor' },
  { id: 6, name: 'Iris' },
  { id: 7, name: 'Ted' },
  { id: 8, name: 'Samuel' },
];
console.log(chalk.green('\n Start Of Integration Tests'));

console.log(chalk.green('\n These Integration Tests are normally located in a separate App.test.tsx file running against an App.tsx file with other components'));

function findTextInMultipleElements(text) {
  const elements = screen.queryAllByText(text);
  return elements.find((element) => element.textContent === text);
}
test('Renders the list of users fetched from the API', async () => {
  // Mock the API response
  console.log(chalk.green(' Running Test [Renders the list of users fetched from the API]'))
  const mockUsers = [
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' },
  ];
  (axios.get as jest.Mock).mockResolvedValueOnce({ data: mockUsers });

  render(<UserList />); // Render the UserList component

  // Wait for the fetchUsers function to complete and update the state
  await waitFor(() => {
    expect(axios.get).toHaveBeenCalledTimes(1); // Ensure the get function was called
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });
});

test('Add a new user through the API', async () => {
  console.log(chalk.green(' Running test [Add a new user through the API]'));
  // Mock the initial API response
  const initialUsers: User[] = [{ id: 1, name: 'John' }];
  (axios.get as jest.Mock).mockResolvedValueOnce({ data: initialUsers });

  render(<UserList />); // Render the UserList component

  // Find the input and button elements
  const inputElement = screen.getByPlaceholderText('Enter name');
  const addButtonElement = screen.getByText('Add User');

  // Type a new user name and click the Add button
  const newName = 'Jane';
  userEvent.type(inputElement, newName);
  userEvent.click(addButtonElement);

  // Mock the API response for adding a user
  const newUser: User = { id: 2, name: newName };
  (axios.post as jest.Mock).mockResolvedValueOnce({ data: newUser });

  // Assert that the new user is added and rendered
  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
    console.log(' Added user ' + '['+newName+']' + ' in test [Add a new user through the API]');
  });
});

test('Delete a user through the API', async () => {
  console.log(chalk.green(' Running test [Delete a user through the API]'));
  // Mock the API response
  const mockUsers: User[] = [
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' },
  ];
  (axios.get as jest.Mock).mockResolvedValueOnce({ data: mockUsers });

  render(<UserList />); // Render the UserList component

  // Assert that the initial users are rendered
  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });

  // Find the delete button for a user and click it
  const deleteButtons = screen.queryAllByText('Delete');
  const deleteButton = deleteButtons.find(button =>
    button.closest('li')?.textContent?.includes('John')
  );
  fireEvent.click(deleteButton);

  // Assert that the user is deleted from the UI
  await waitFor(() => {
    expect(screen.queryByText('John')).toBeNull();
    expect(screen.getByText('Jane')).toBeInTheDocument();
    console.log(' Deleted user ' + '['+mockUsers[1].name+']' + ' in test [Delete a new user through the API]');
  });
});

test('Update a user through the API', async () => {
  console.log(chalk.green(' Running test [Update a user through the API]'));
  // Mock the API response
  const mockUsers: User[] = [
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' },
  ];
  (axios.get as jest.Mock).mockResolvedValueOnce({ data: mockUsers });

  render(<UserList />); // Render the UserList component

  // Wait for the initial users to be rendered
  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
  });

  // Find the update button for the first user
  const updateButton = screen.getAllByText('Update')[0]; // Get the first "Update" button

  // Click the update button
  userEvent.click(updateButton);

  // Find the input field for updating the user
  const inputElement = screen.getByPlaceholderText('Enter name');

  // Clear the input field and type the new name
  userEvent.clear(inputElement);
  userEvent.type(inputElement, 'Tekla');

  // Mock the API response for updating a user
  const updatedUser: User = { id: 1, name: 'Tekla' };
  (axios.post as jest.Mock).mockResolvedValueOnce({ data: updatedUser });

  // Simulate submitting the update form
  userEvent.type(inputElement, '{enter}');

  // Assert that the user is updated and rendered
  await waitFor(() => {
    expect(screen.getByText('Tekla')).toBeInTheDocument();
    expect(screen.getByText('Jane')).toBeInTheDocument();
    console.log(' Updated user ' + '['+mockUsers[1].name+']' + ' in test [Update a user through the API]');
  });
});

test('Handles error when adding a user through the API', async () => {
  console.log(chalk.green(' Running test [Handles error when adding a user through the API]'));
  render(<UserList />);

  // Mock the console.error function
  const consoleErrorMock = jest.spyOn(console, 'error').mockImplementation();

  // Find the input and button elements
  const inputElement = screen.getByPlaceholderText('Enter name');
  const addButtonElement = screen.getByText('Add User');

  // Type a new user name and click the Add button
  const newName = 'Jane';
  userEvent.type(inputElement, newName);
  userEvent.click(addButtonElement);

  // Mock the API response to throw an error
  (axios.post as jest.MockedFunction<typeof axios.post>).mockRejectedValueOnce(new Error('API error'));

  // Assert that the error message is logged
  await waitFor(() => {
    expect(consoleErrorMock).toHaveBeenCalledWith('Error adding user:', expect.any(Error));
    console.log(' Expected match of API error when adding user in test [Handles error when adding a user through the API]');
  });

  // Restore the original console.error function
  consoleErrorMock.mockRestore();
});

test('Handles error when deleting a user through the API', async () => {
  console.log(chalk.green(' Running test [Handles error when deleting a user through the API]'));
  const initialUsers: User[] = [{ id: 1, name: 'John' }];
  (axios.get as jest.MockedFunction<typeof axios.get>).mockResolvedValueOnce({ data: initialUsers });

  render(<UserList />);

  // Mock the console.error function
  const consoleErrorMock = jest.spyOn(console, 'error').mockImplementation();

  // Find the delete button for user with ID 1
  const deleteButtonElement = screen.queryByTestId('delete-button-1');
  
  // If the delete button is not found, log an error and fail the test
  if (!deleteButtonElement) {
    console.error(' Delete button not found for user ID 1');
    return;
  }

  // Click the delete button
  userEvent.click(deleteButtonElement);

  // Mock the API response to throw an error
  (axios.delete as jest.MockedFunction<typeof axios.delete>).mockRejectedValueOnce(new Error('API error'));

  // Assert that the error message is logged
  await waitFor(() => {
    expect(consoleErrorMock).toHaveBeenCalledWith('Error deleting user:', expect.any(Error));
  });

  // Restore the original console.error function
  consoleErrorMock.mockRestore();
});

test('Handles error when updating a user through the API', async () => {
  console.log(chalk.green(' Running test [Handles error when updating a user through the API]'));
  const initialUsers: User[] = [{ id: 1, name: 'John' }];
  (axios.get as jest.MockedFunction<typeof axios.get>).mockResolvedValueOnce({ data: initialUsers });

  render(<UserList />);

  // Wait for the initial user to be rendered to make sure that it is possible to make the update
  await waitFor(() => {
    expect(screen.getByText('John')).toBeInTheDocument();
  });

  // Mock the API response for updating a user to throw an error
  (axios.put as jest.MockedFunction<typeof axios.put>).mockRejectedValueOnce(new Error('API error'));

  // Find the update button for user with ID 1
  const updateButtonElement = screen.getByTestId('update-button-1');

  // Click the update button
  userEvent.click(updateButtonElement);

  // Get the user ID from the initialUsers array
  const userId = initialUsers[0].id;

  // Assert that the error message is logged with the correct user ID
  await waitFor(() => {
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining(`Error updating user with userId: ${userId}`),
      expect.any(Error)
    );
  });
});
test('Displays an error message when the API call fails', async () => {
  console.log(chalk.green(' Running test [Displays an error message when the API call fails]'));
  const errorMessage = 'Failed to fetch users.';
  const mockRejectedValue = Promise.reject(new Error(errorMessage));

  (axios.get as jest.Mock).mockImplementationOnce(() => mockRejectedValue);

  render(<UserList />);

  await waitFor(() => {
    const errorElement = screen.getByText(errorMessage);
    console.log(' Expected Error occurred while fetching users:', errorMessage); 
    expect(errorElement).toBeInTheDocument();
  });
});

test('Displays a message when no users are returned from the API', async () => {
  console.log(chalk.green(' Running test [Displays a message when no users are returned from the API]'));
  const emptyMessage = /No users found\./;

  const mockResolvedValue = { data: [] };
  jest.spyOn(axios, 'get').mockResolvedValue(mockResolvedValue);

  render(<UserList />);

  await waitFor(() => {
    const emptyElement = screen.queryByText(emptyMessage);
    if (emptyElement === null) {
      console.log(' Expected message found - \'No users found.\' Element is NULL'); 
    }
    expect(emptyElement).toBeNull();
  });
});

// Add test 'Add and Delete User through the API'

// Add test 'Performance Test: Delete 52 users through the API' (use the list multipleUserList)
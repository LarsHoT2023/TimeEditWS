import React, { useState } from 'react';

const Counter = () => {
  const [count, setCount] = useState(0);
  const limit = 10; //Just for fun add a limit

  const increment = () => {
    setCount(prevCount => {
      const currentCount = typeof prevCount === 'number' ? prevCount : parseInt(prevCount, limit);
      if (isNaN(currentCount)) {
        // Return the current count if it is a non-numeric value
        return currentCount;
      }
      const incrementedCount = Math.min(currentCount + 1, limit);
      return incrementedCount;
    });
  };
  
  const decrement = () => {
    setCount(prevCount => {
      const currentCount = typeof prevCount === 'number' ? prevCount : parseInt(prevCount, limit);
      if (isNaN(currentCount)) {
        // Return the current count if it is a non-numeric value
        return currentCount;
      }
      //Count cannot be lower then zero
      const decrementedCount = Math.max(currentCount - 1, 0);
      return decrementedCount;
    });
  };
  

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>
    </div>
  );
};

export default Counter;

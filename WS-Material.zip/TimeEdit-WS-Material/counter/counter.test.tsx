import React, { useState, Dispatch, SetStateAction } from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

import Counter from './counter';

describe('Counter component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // Test: Renders the count
  it('Render the counter component', () => {
    // Render the Counter component
    const { getByText } = render(<Counter />);
    // Expect the text "Count: 0" to be present
    expect(getByText(/Count:/)).toHaveTextContent('Count: 0');
  });

  // Test: Increments the count when the increment button is clicked
  it('Increment the count when the increment button is clicked', async () => {
    // Render the Counter component
    const { getByText } = render(<Counter />);
    const incrementButton = getByText('Increment');
    // Simulate a click on the increment button
    fireEvent.click(incrementButton);
    // Wait for the component to update and expect the text "Count: 1" to be present
    await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 1'));
  });

  // Test: Decrements the count when the decrement button is clicked
  it('Decrement the count when the decrement button is clicked', async () => {
    // Render the Counter component
    const { getByText } = render(<Counter />);
    const incrementButton = getByText('Increment');
    // Simulate a click on the increment button
    fireEvent.click(incrementButton);
    const decrementButton = getByText('Decrement');
    // Simulate a click on the decrement button
    fireEvent.click(decrementButton);
    // Wait for the component to update and expect the text "Count: 0" to be present
    await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 0'));
  });

  // Test: Does not go below zero when the decrement button is clicked
  it('Does not go below zero when the decrement button is clicked', async () => {
    // Render the Counter component
    const { getByText } = render(<Counter />);
    const decrementButton = getByText('Decrement');
    // Simulate multiple clicks on the decrement button
    fireEvent.click(decrementButton);
    fireEvent.click(decrementButton);
    // Wait for the component to update and expect the text "Count: 0" to be present
    await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 0'));
  });

  // Test: Does not go above a certain limit when the increment button is clicked
  it('Does not go above a certain limit when the increment button is clicked', async () => {
    const { getByText } = render(<Counter />);
    const incrementButton = getByText('Increment');
    const limit = 10;
  
    for (let i = 0; i < limit; i++) {
      fireEvent.click(incrementButton);
      await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent(`Count: ${Math.min(i + 1, limit)}`));
    }
  
    // Simulate additional clicks on the increment button
    for (let i = limit; i < limit + 5; i++) {
      fireEvent.click(incrementButton);
      await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent(`Count: ${limit}`));
    }
  });
  
 // Test: Handles a mix of numeric and non-numeric values correctly
it('Handles a mix of numeric and non-numeric values correctly', async () => {
  // Render the Counter component
  const { getByText } = render(<Counter />);
  const incrementButton = getByText('Increment');

  // Increment the count by 1 three times
  fireEvent.click(incrementButton);
  await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 1'));
  fireEvent.click(incrementButton);
  await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 2'));
  fireEvent.click(incrementButton);
  await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 3'));

  // Set the count to a non-numeric value ('X' in this case)
  /*
  By using jest.spyOn and mockImplementationOnce, we can temporarily override the 
  behavior of useState for the duration of this test case. This allows us to 
  simulate setting the count to a non-numeric value and ensure 
  that the count remains unchanged when the increment button is clicked.
  */
  const setCountMock = jest.fn();
  jest.spyOn(React, 'useState').mockImplementationOnce(() => ['X', setCountMock]);

  // Simulate a click on the increment button
  fireEvent.click(incrementButton);

  // Expect the count to remain unchanged (still 3)
  await waitFor(() => expect(getByText(/Count:/)).toHaveTextContent('Count: 3'));
});



});


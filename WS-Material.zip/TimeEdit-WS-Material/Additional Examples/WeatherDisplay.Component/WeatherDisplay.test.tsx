import React from 'react';
import { render } from '@testing-library/react';
import WeatherDisplay from './WeatherDisplay';

test('renders weather data', () => {
  const mockWeatherData = {
    city: 'Test City',
    temperature: 25,
    humidity: 60,
    description: 'Clear sky',
  };

  const { getByText } = render(<WeatherDisplay cityName="Test City" />);
  expect(getByText(`Weather for ${mockWeatherData.city}`)).toBeInTheDocument();
  expect(getByText(`Temperature: ${mockWeatherData.temperature}°C`)).toBeInTheDocument();
  expect(getByText(`Humidity: ${mockWeatherData.humidity}%`)).toBeInTheDocument();
  expect(getByText(`Description: ${mockWeatherData.description}`)).toBeInTheDocument();
});

test('renders without crashing', () => {
  const { container } = render(<WeatherDisplay cityName="Test City" />);
  expect(container.firstChild).toBeInTheDocument();
});
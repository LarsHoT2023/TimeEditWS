import React from 'react';
import { render, screen } from '@testing-library/react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import App from './App';

const server = setupServer(
  rest.get('/api/weather/New York', (req, res, ctx) => {
    return res(ctx.json({
      city: 'New York',
      temperature: 25,
      humidity: 60,
      description: 'Sunny',
    }));
  })
);

beforeAll(() => server.listen());
afterEach(() => {
  server.resetHandlers();
  // Add additional cleanup for actual database connections if needed
});
afterAll(() => server.close());

describe('WeatherDisplay component with mixed testing', () => {
  test('renders weather data from mock', async () => {
    render(<App />);
    await screen.findByText('Weather for New York');
    expect(screen.getByText('Temperature: 25°C')).toBeInTheDocument();
    expect(screen.getByText('Humidity: 60%')).toBeInTheDocument();
    expect(screen.getByText('Description: Sunny')).toBeInTheDocument();
  });

  test('renders weather data from actual database', async () => {
    // Disable the mock for this specific test
    server.use(
      rest.get('/api/weather/New York', async (req, res, ctx) => {
        // Make an actual call to the database or API here
        const data = await makeActualDatabaseCall();
        return res(ctx.json(data));
      })
    );

    render(<App />);
    await screen.findByText('Weather for New York');
    // Additional assertions based on actual data
  });
});


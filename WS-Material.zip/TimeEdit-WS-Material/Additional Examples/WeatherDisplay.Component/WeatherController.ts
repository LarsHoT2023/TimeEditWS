import { Request, Response } from 'express';
import WeatherModel from './WeatherModel';

export const getWeatherData = async (req: Request, res: Response) => {
  const { cityName } = req.params;
  try {
    const weatherData = await WeatherModel.findOne({ city: cityName });
    res.json(weatherData);
  } catch (error) {
    console.error('Error fetching weather data:', error);
    res.status(500).json({ error: 'An error occurred while fetching weather data.' });
  }
};

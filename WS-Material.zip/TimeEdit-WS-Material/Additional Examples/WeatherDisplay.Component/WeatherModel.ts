import mongoose, { Document, Schema } from 'mongoose';

interface WeatherData extends Document {
  city: string;
  temperature: number;
  humidity: number;
  description: string;
}

const weatherSchema = new Schema({
  city: String,
  temperature: Number,
  humidity: Number,
  description: String,
});

const WeatherModel = mongoose.model<WeatherData>('Weather', weatherSchema);

export default WeatherModel;

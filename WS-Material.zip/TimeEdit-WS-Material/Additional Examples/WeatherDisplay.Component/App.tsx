import React from 'react';
import WeatherDisplay from './WeatherDisplay';

const App: React.FC = () => {
  // Sample weather data
  const weatherData = {
    city: 'New York',
    temperature: 25,
    humidity: 60,
    description: 'Sunny',
  };

  return (
    <div>
      <h1>Weather App</h1>
      <WeatherDisplay
        city={weatherData.city}
        temperature={weatherData.temperature}
        humidity={weatherData.humidity}
        description={weatherData.description}
      />
    </div>
  );
};

export default App;

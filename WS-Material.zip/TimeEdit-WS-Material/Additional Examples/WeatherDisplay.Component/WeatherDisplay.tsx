import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface WeatherData {
  city: string;
  temperature: number;
  humidity: number;
  description: string;
}

interface WeatherDisplayProps {
  city: string;
  temperature: number;
  humidity: number;
  description: string;
}

const WeatherDisplay: React.FC<WeatherDisplayProps> = ({ city, temperature, humidity, description }) => {
  return (
    <div>
      <h2>Weather for {city}</h2>
      <p>Temperature: {temperature}°C</p>
      <p>Humidity: {humidity}%</p>
      <p>Description: {description}</p>
    </div>
  );
};

export default WeatherDisplay;

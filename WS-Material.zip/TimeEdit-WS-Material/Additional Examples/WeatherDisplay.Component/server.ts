import express from 'express';
import mongoose from 'mongoose';
import { getWeatherData } from './WeatherController';

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb://localhost:27017/weatherdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.get('/api/weather/:cityName', getWeatherData);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

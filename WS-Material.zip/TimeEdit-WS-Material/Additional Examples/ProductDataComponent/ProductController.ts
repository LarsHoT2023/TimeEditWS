// Please note that directly connecting to the database from the frontend is generally not recommended for security reasons. In a real-world 
// scenario, the frontend should communicate with a backend server, and the backend server should handle the database interactions securely.

// For this example, we'll use mssql package to make the connection to the SQL Server from the Controller. However, remember that this is 
// just a basic demonstration, and in production, you should have a separate backend server handling the database connections securely.
// Install mssql command - npm install mssql
// This example is just for demonstration purpose

import { ConnectionPool, sql } from 'mssql';

export class ProductController {
  private config = {
    user: 'your_username',
    password: 'your_password',
    server: 'your_server', // Usually in the format "localhost\\instancename" for default instance.
    database: 'your_database',
    options: {
      encrypt: true, // If your SQL Server uses encrypted connections (usually recommended for security).
    },
  };

  async fetchProducts(): Promise<string[]> {
    try {
      const pool = await new ConnectionPool(this.config).connect();
      const result = await pool
        .request()
        .execute('YourStoredProcedureName');

      pool.close();
      return result.recordset.map((record: any) => record.productName);
    } catch (err) {
      console.error('Error executing stored procedure:', err);
      return [];
    }
  }
}

// Without the above code you can mock the call to the backend like in the notes-controller.txt file

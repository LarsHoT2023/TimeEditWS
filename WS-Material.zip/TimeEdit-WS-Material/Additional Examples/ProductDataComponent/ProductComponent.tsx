import React, { useEffect, useState } from 'react';
import { ProductController } from './ProductController';

const ProductComponent: React.FC = () => {
  const [products, setProducts] = useState<string[]>([]);

  useEffect(() => {
    const controller = new ProductController();
    controller.fetchProducts().then((data) => setProducts(data));
  }, []);

  return (
    <div>
      <h2>Product Component</h2>
      <ul>
        {products.map((product, index) => (
          <li key={index}>{product}</li>
        ))}
      </ul>
    </div>
  );
};

export default ProductComponent;

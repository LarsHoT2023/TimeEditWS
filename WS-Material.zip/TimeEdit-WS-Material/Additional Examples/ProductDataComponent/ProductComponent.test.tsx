// Unit Test
import React from 'react';
import { render } from '@testing-library/react';
import ProductComponent from './ProductComponent';

test('renders Product Component with product list', () => {
  const { getByText } = render(<ProductComponent />);

  const product1Element = getByText('Product 1');
  const product2Element = getByText('Product 2');
  const product3Element = getByText('Product 3');

  expect(product1Element).toBeInTheDocument();
  expect(product2Element).toBeInTheDocument();
  expect(product3Element).toBeInTheDocument();
});

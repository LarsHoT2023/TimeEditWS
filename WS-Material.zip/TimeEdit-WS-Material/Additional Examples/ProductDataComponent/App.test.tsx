// Integration Test
import React from 'react';
import { render, waitForElementToBeRemoved } from '@testing-library/react';
import App from './App';

test('renders App component with Product Component and fetches product data', async () => {
  const { getByText, queryByText } = render(<App />);
  const productComponentElement = getByText('Product Component');

  expect(productComponentElement).toBeInTheDocument();

  // Wait for product data to be fetched
  await waitForElementToBeRemoved(() => queryByText('Product Component'));
});

import React from 'react';
import ProductComponent from './ProductComponent';

const App: React.FC = () => (
  <div>
    <h1>App Component</h1>
    <ProductComponent />
  </div>
);

export default App;
